Usage.

Intended setup is 1920X1080 at a 16:9 aspect however if your computer has a poor graphics card
or if your unsure, lower the resolution and quality. If you expect it to freez or crash check the windowed checkbox
when starting it. 

enter key moves the presentation forward, backspace key moves it back one slide There is one bug with the mony drop effect to avoid
it make sure to wait for the effect to end on the 2and money counter (the one after 260,000,000) the first counter however can be 
skipped by pressing enter. 

to close the application you will need to use task manager.